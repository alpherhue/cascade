# App Blueprint: "ChaoSphere" - Anonymous Forum Platform

## 1. Project Breakdown

**Platform:** Web application (responsive design)

**Summary:** ChaoSphere is a modern anonymous forum platform inspired by sites like BreachForums and Raids. The platform enables users to engage in uncensored discussions through threads and replies while maintaining anonymity. Key features include mandatory sign-up to view/post content, thread categorization, and real-time updates. The goal is to create a lightweight but functional forum with minimal barriers to entry while preventing spam through basic authentication.

**Primary Use Case:**
- Anonymous users browse forum categories
- Signed-up users create/view threads and post replies
- Real-time updates for thread activity
- Simple content moderation interface

**Authentication Requirements:**
- Email/password signup with Supabase Auth
- Guest users can only view category listings
- Verified accounts required for posting
- No personal data collection beyond email

## 2. Tech Stack Overview

**Frontend Framework:** React + Next.js (App Router)
- Dynamic route handling for threads/categories
- Server components for SEO-optimized public pages
- Client components for interactive elements

**UI Library:** Tailwind CSS + ShadCN
- Pre-built accessible components from ShadCN
- Custom styling with Tailwind
- Dark/light mode support

**Backend (BaaS):** Supabase
- PostgreSQL database for threads/replies
- Real-time subscriptions for new posts
- Row-level security for data protection
- Storage for potential image uploads

**Deployment:** Vercel
- Automatic preview deployments
- Edge functions for Supabase integration
- Global CDN distribution

## 3. Core Features

**Forum Structure:**
- Category listing (visible to all)
- Thread lists per category (authenticated only)
- Nested reply system

**User System:**
- Anonymous display names (auto-generated)
- Email verification flow
- Basic user profiles (post history only)

**Content Features:**
- Markdown support for posts
- Basic text formatting
- Thread locking/pinning (mods only)

**Moderation:**
- Report system
- Basic admin dashboard
- Post deletion/editing

**Real-time Features:**
- Live reply counters
- New post notifications
- Online user indicators

## 4. User Flow

**Guest Flow:**
1. Lands on category listing page
2. Sees "sign up to view content" placeholders
3. Clicks signup → email/password form
4. Receives verification email
5. Returns to authenticated experience

**Authenticated Flow:**
1. Views full category list
2. Selects category → sees thread list
3. Clicks thread → views content and replies
4. Can:
   - Post new reply (textarea appears)
   - Create new thread (button in category)
   - Report content (flag icon)

**Moderator Flow:**
1. Additional admin panel access
2. Special indicators in thread view
3. Additional action buttons (pin/lock/delete)

## 5. Design & UI/UX Guidelines

**Layout Principles:**
- Mobile-first responsive design
- Fixed-width content area (1200px max)
- Sticky header with auth status

**Visual Hierarchy:**
1. Category cards (grid layout)
2. Thread list (compact table)
3. Reply tree (indented comments)

**Component Design:**
- ShadCN for base components (cards, buttons)
- Custom Tailwind styles for:
  - Thread cards (hover effects)
  - Reply nesting visual indicators
  - Distinction between OPs and replies

**Interaction Design:**
- Instant form validation
- Optimistic UI for posts
- Loading skeletons for content

**Accessibility:**
- WCAG AA compliance
- Keyboard navigable
- Reduced motion options

## 6. Technical Implementation

**Frontend Structure:**
```
/app
  /(public)         # Guest-accessible
    /categories
  /(auth)           # Auth-required
    /[category]
    /[thread]
  /api              # Route handlers
```

**Supabase Integration:**
1. Set up row-level security policies
2. Database schema:
   - `profiles` (user_id, display_name)
   - `categories` (id, name, description)
   - `threads` (id, category_id, user_id, title)
   - `replies` (id, thread_id, user_id, content)

**Key Implementation Details:**
- Real-time updates via Supabase subscriptions
- Server-side protected routes with Next.js middleware
- Optimistic updates for post submissions
- Rate limiting at database level

**Authentication Flow:**
1. NextAuth.js configured with Supabase provider
2. Custom credential handler for email/password
3. Session management via cookies

## 7. Development Setup

**Requirements:**
- Node.js 18+
- Supabase account
- Vercel account

**Setup Instructions:**

1. Initialize Next.js app:
```bash
npx create-next-app@latest --typescript
```

2. Install dependencies:
```bash
npm install @supabase/supabase-js @supabase/ssr next-auth @radix-ui/react-dropdown-menu tailwind-merge clsx tailwindcss-animate
```

3. Configure Supabase:
```bash
npm install @supabase/supabase-js
```
Create `.env.local` with:
```env
NEXT_PUBLIC_SUPABASE_URL=your-url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-key
```

4. Set up ShadCN:
```bash
npx shadcn-ui@latest init
npx shadcn-ui@latest add button card input textarea
```

5. Run development server:
```bash
npm run dev
```

**Vercel Deployment:**
1. Connect Git repository
2. Add same environment variables
3. Enable Edge Functions
4. Set up automatic deployments

**Supabase Setup:**
1. Enable Email auth provider
2. Configure email templates
3. Set up database schema with RLS
4. Create storage bucket for assets