import { VercelRequest, VercelResponse } from '@vercel/node';
import { storage } from '../storage';

export default async function handler(request: VercelRequest, response: VercelResponse) {
  try {
    const categories = await storage.getAllCategories();
    response.status(200).json(categories);
  } catch (error) {
    response.status(500).json({ error: 'Internal server error' });
  }
}