import { VercelRequest, VercelResponse } from '@vercel/node';
import { storage } from '../storage';
import { parseCookies } from './utils';

export default async function handler(request: VercelRequest, response: VercelResponse) {
  try {
    // In a real Vercel deployment, you would use a JWT token or session mechanism
    // Here we're simulating the session-based auth from the original app
    const cookies = parseCookies(request);
    const userId = cookies['userId'];
    
    if (!userId) {
      return response.status(401).json({ error: 'Not authenticated' });
    }
    
    const user = await storage.getUser(parseInt(userId));
    if (!user) {
      return response.status(401).json({ error: 'User not found' });
    }
    
    response.status(200).json(user);
  } catch (error) {
    response.status(500).json({ error: 'Internal server error' });
  }
}