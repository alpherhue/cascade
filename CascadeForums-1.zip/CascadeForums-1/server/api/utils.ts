import { VercelRequest } from '@vercel/node';

export function parseCookies(request: VercelRequest): Record<string, string> {
  const cookieHeader = request.headers.cookie;
  if (!cookieHeader) return {};
  
  return cookieHeader.split(';').reduce((cookies: Record<string, string>, cookie: string) => {
    const [name, value] = cookie.trim().split('=');
    cookies[name] = decodeURIComponent(value);
    return cookies;
  }, {} as Record<string, string>);
}