import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { WebSocketServer } from "ws";
import { 
  insertCategorySchema, 
  insertThreadSchema, 
  insertReplySchema,
  insertReportSchema,
  insertTagSchema
} from "@shared/schema";
import WebSocket from "ws";

// Middleware to check if user is authenticated
const isAuthenticated = (req: Request, res: Response, next: Function) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Create HTTP server
  const httpServer = createServer(app);

  // Setup WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws) => {
    ws.on('message', (message) => {
      const data = JSON.parse(message.toString());
      console.log('Received message:', data);
    });

    // Send welcome message
    ws.send(JSON.stringify({ type: 'connect', message: 'Connected to Cascade Forums WebSocket server' }));
  });

  // Broadcast to all connected clients
  const broadcast = (data: any) => {
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(data));
      }
    });
  };

  // Categories routes
  app.get('/api/categories', async (req, res) => {
    try {
      const categories = await storage.getAllCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Error fetching categories" });
    }
  });

  app.get('/api/categories/:id', async (req, res) => {
    try {
      const category = await storage.getCategory(parseInt(req.params.id));
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Error fetching category" });
    }
  });

  app.post('/api/categories', isAuthenticated, async (req, res) => {
    try {
      const user = req.user as Express.User;
      if (!user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const validatedData = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(validatedData);
      
      broadcast({ type: 'category_created', data: category });
      res.status(201).json(category);
    } catch (error) {
      res.status(500).json({ message: "Error creating category" });
    }
  });

  // Threads routes
  app.get('/api/threads', isAuthenticated, async (req, res) => {
    try {
      const categoryId = req.query.categoryId ? parseInt(req.query.categoryId as string) : undefined;
      const threads = categoryId 
        ? await storage.getThreadsByCategory(categoryId)
        : await storage.getAllThreads();
      res.json(threads);
    } catch (error) {
      res.status(500).json({ message: "Error fetching threads" });
    }
  });

  app.get('/api/threads/:id', isAuthenticated, async (req, res) => {
    try {
      const thread = await storage.getThread(parseInt(req.params.id));
      if (!thread) {
        return res.status(404).json({ message: "Thread not found" });
      }
      res.json(thread);
    } catch (error) {
      res.status(500).json({ message: "Error fetching thread" });
    }
  });

  app.post('/api/threads', isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertThreadSchema.parse(req.body);
      const user = req.user as Express.User;
      const thread = await storage.createThread({
        ...validatedData,
        userId: user.id,
      });
      
      broadcast({ type: 'thread_created', data: thread });
      res.status(201).json(thread);
    } catch (error) {
      res.status(500).json({ message: "Error creating thread" });
    }
  });

  // Replies routes
  app.get('/api/replies', isAuthenticated, async (req, res) => {
    try {
      const threadId = req.query.threadId ? parseInt(req.query.threadId as string) : undefined;
      if (!threadId) {
        return res.status(400).json({ message: "Thread ID is required" });
      }
      
      const replies = await storage.getRepliesByThread(threadId);
      res.json(replies);
    } catch (error) {
      res.status(500).json({ message: "Error fetching replies" });
    }
  });

  app.post('/api/replies', isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertReplySchema.parse(req.body);
      const user = req.user as Express.User;
      const reply = await storage.createReply({
        ...validatedData,
        userId: user.id,
      });
      
      broadcast({ type: 'reply_created', data: reply });
      res.status(201).json(reply);
    } catch (error) {
      res.status(500).json({ message: "Error creating reply" });
    }
  });

  // User profile routes
  app.get('/api/users/:id/threads', isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const threads = await storage.getThreadsByUser(userId);
      res.json(threads);
    } catch (error) {
      res.status(500).json({ message: "Error fetching user threads" });
    }
  });

  app.get('/api/users/:id/replies', isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const replies = await storage.getRepliesByUser(userId);
      res.json(replies);
    } catch (error) {
      res.status(500).json({ message: "Error fetching user replies" });
    }
  });

  // Tags routes
  app.get('/api/tags', async (req, res) => {
    try {
      const tags = await storage.getAllTags();
      res.json(tags);
    } catch (error) {
      res.status(500).json({ message: "Error fetching tags" });
    }
  });

  app.post('/api/tags', isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertTagSchema.parse(req.body);
      const tag = await storage.createTag(validatedData);
      res.status(201).json(tag);
    } catch (error) {
      res.status(500).json({ message: "Error creating tag" });
    }
  });

  // Thread tags routes
  app.post('/api/threads/:threadId/tags/:tagId', isAuthenticated, async (req, res) => {
    try {
      const threadId = parseInt(req.params.threadId);
      const tagId = parseInt(req.params.tagId);
      
      await storage.addTagToThread(threadId, tagId);
      res.status(201).json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Error adding tag to thread" });
    }
  });

  // Likes and reporting
  app.post('/api/threads/:id/like', isAuthenticated, async (req, res) => {
    try {
      const threadId = parseInt(req.params.id);
      const userId = (req.user as Express.User).id;
      
      await storage.likeThread(userId, threadId);
      broadcast({ type: 'thread_liked', data: { threadId, userId } });
      res.status(201).json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Error liking thread" });
    }
  });

  app.post('/api/replies/:id/like', isAuthenticated, async (req, res) => {
    try {
      const replyId = parseInt(req.params.id);
      const userId = (req.user as Express.User).id;
      
      await storage.likeReply(userId, replyId);
      broadcast({ type: 'reply_liked', data: { replyId, userId } });
      res.status(201).json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Error liking reply" });
    }
  });

  app.post('/api/reports', isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertReportSchema.parse(req.body);
      const userId = (req.user as Express.User).id;
      
      const report = await storage.createReport({
        ...validatedData,
        userId,
      });
      
      if ((req.user as Express.User).isAdmin) {
        broadcast({ type: 'report_created', data: report });
      }
      
      res.status(201).json(report);
    } catch (error) {
      res.status(500).json({ message: "Error creating report" });
    }
  });

  // Admin routes
  app.get('/api/admin/reports', isAuthenticated, async (req, res) => {
    try {
      const user = req.user as Express.User;
      if (!user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const reports = await storage.getAllReports();
      res.json(reports);
    } catch (error) {
      res.status(500).json({ message: "Error fetching reports" });
    }
  });

  app.patch('/api/admin/threads/:id', isAuthenticated, async (req, res) => {
    try {
      const user = req.user as Express.User;
      if (!user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const threadId = parseInt(req.params.id);
      const { isPinned, isLocked } = req.body;
      
      const thread = await storage.updateThread(threadId, { isPinned, isLocked });
      broadcast({ type: 'thread_updated', data: thread });
      res.json(thread);
    } catch (error) {
      res.status(500).json({ message: "Error updating thread" });
    }
  });

  return httpServer;
}
