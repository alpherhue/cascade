import { 
  User, InsertUser, 
  Category, InsertCategory, 
  Thread, InsertThread, 
  Reply, InsertReply,
  Tag, InsertTag,
  Report, InsertReport
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

// Extended Thread type with additional data
export type ThreadWithData = Thread & {
  author: User;
  category: Category;
  replyCount: number;
  tags: Tag[];
};

// Extended Reply type with additional data
export type ReplyWithData = Reply & {
  author: User;
  likes: number;
};

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser & { displayName: string }): Promise<User>;

  // Category methods
  getAllCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;

  // Thread methods
  getAllThreads(): Promise<ThreadWithData[]>;
  getThread(id: number): Promise<ThreadWithData | undefined>;
  getThreadsByCategory(categoryId: number): Promise<ThreadWithData[]>;
  getThreadsByUser(userId: number): Promise<ThreadWithData[]>;
  createThread(thread: InsertThread & { userId: number }): Promise<Thread>;
  updateThread(id: number, updates: Partial<Thread>): Promise<Thread>;

  // Reply methods
  getRepliesByThread(threadId: number): Promise<ReplyWithData[]>;
  getRepliesByUser(userId: number): Promise<ReplyWithData[]>;
  createReply(reply: InsertReply & { userId: number }): Promise<Reply>;

  // Tag methods
  getAllTags(): Promise<Tag[]>;
  createTag(tag: InsertTag): Promise<Tag>;
  addTagToThread(threadId: number, tagId: number): Promise<void>;
  getTagsByThread(threadId: number): Promise<Tag[]>;

  // Like and report methods
  likeThread(userId: number, threadId: number): Promise<void>;
  likeReply(userId: number, replyId: number): Promise<void>;
  createReport(report: InsertReport & { userId: number }): Promise<Report>;
  getAllReports(): Promise<Report[]>;

  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private threads: Map<number, Thread>;
  private replies: Map<number, Reply>;
  private tags: Map<number, Tag>;
  private threadTags: Map<number, Set<number>>;
  private likes: Map<string, boolean>;
  private reports: Map<number, Report>;
  
  private userCounter: number;
  private categoryCounter: number;
  private threadCounter: number;
  private replyCounter: number;
  private tagCounter: number;
  private reportCounter: number;
  
  sessionStore: session.SessionStore;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.threads = new Map();
    this.replies = new Map();
    this.tags = new Map();
    this.threadTags = new Map();
    this.likes = new Map();
    this.reports = new Map();
    
    this.userCounter = 1;
    this.categoryCounter = 1;
    this.threadCounter = 1;
    this.replyCounter = 1;
    this.tagCounter = 1;
    this.reportCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // 24h
    });
    
    // Initialize with sample categories
    this.seedCategories();
  }

  // Seed initial categories
  private seedCategories() {
    const categories: InsertCategory[] = [
      {
        name: "Programming",
        description: "Discuss programming languages, software development, and coding challenges.",
        icon: "code-box-line",
        color: "primary-500",
      },
      {
        name: "Gaming",
        description: "Discussions about video games, gaming news, and finding teammates for multiplayer.",
        icon: "gamepad-line",
        color: "secondary-500",
      },
      {
        name: "Tech News",
        description: "The latest in technology news, product launches, and industry analysis.",
        icon: "lightbulb-line",
        color: "cyan-500",
      },
      {
        name: "Mobile Development",
        description: "iOS, Android, and cross-platform app development discussions.",
        icon: "smartphone-line",
        color: "blue-500",
      },
      {
        name: "Data Science",
        description: "Machine learning, data analysis, and AI research.",
        icon: "database-2-line",
        color: "purple-500",
      },
      {
        name: "Web Development",
        description: "Frontend, backend, and everything in between.",
        icon: "code-s-slash-line",
        color: "green-500",
      },
      {
        name: "Artificial Intelligence",
        description: "AI technologies, neural networks, and model development.",
        icon: "robot-line",
        color: "red-500",
      },
      {
        name: "Cloud Computing",
        description: "AWS, Azure, GCP, and general cloud architecture discussions.",
        icon: "cloud-line",
        color: "cyan-500",
      },
      {
        name: "Cybersecurity",
        description: "Security best practices, vulnerabilities, and threat intelligence.",
        icon: "shield-check-line",
        color: "amber-500",
      },
      {
        name: "Crypto & Blockchain",
        description: "Cryptocurrencies, blockchain technology, and Web3 development.",
        icon: "vip-crown-line",
        color: "yellow-500",
      },
      {
        name: "Off-Topic",
        description: "General discussion about anything not covered in other categories.",
        icon: "discuss-line",
        color: "pink-500",
      }
    ];
    
    categories.forEach(category => {
      this.createCategory(category);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async createUser(userData: InsertUser & { displayName: string }): Promise<User> {
    const timestamp = new Date();
    const id = this.userCounter++;
    const user: User = {
      id,
      username: userData.username,
      password: userData.password,
      email: userData.email,
      displayName: userData.displayName,
      createdAt: timestamp,
      isAdmin: false
    };
    
    this.users.set(id, user);
    return user;
  }

  // Category methods
  async getAllCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const id = this.categoryCounter++;
    const timestamp = new Date();
    
    const newCategory: Category = {
      id,
      name: category.name,
      description: category.description,
      icon: category.icon,
      color: category.color,
      createdAt: timestamp
    };
    
    this.categories.set(id, newCategory);
    return newCategory;
  }

  // Thread methods
  async getAllThreads(): Promise<ThreadWithData[]> {
    return Promise.all(
      Array.from(this.threads.values()).map(async (thread) => {
        return this.getThreadWithData(thread);
      })
    );
  }

  async getThread(id: number): Promise<ThreadWithData | undefined> {
    const thread = this.threads.get(id);
    if (!thread) return undefined;
    
    return this.getThreadWithData(thread);
  }

  async getThreadsByCategory(categoryId: number): Promise<ThreadWithData[]> {
    const threads = Array.from(this.threads.values()).filter(
      (thread) => thread.categoryId === categoryId
    );
    
    return Promise.all(
      threads.map(async (thread) => {
        return this.getThreadWithData(thread);
      })
    );
  }

  async getThreadsByUser(userId: number): Promise<ThreadWithData[]> {
    const threads = Array.from(this.threads.values()).filter(
      (thread) => thread.userId === userId
    );
    
    return Promise.all(
      threads.map(async (thread) => {
        return this.getThreadWithData(thread);
      })
    );
  }

  async createThread(threadData: InsertThread & { userId: number }): Promise<Thread> {
    const id = this.threadCounter++;
    const timestamp = new Date();
    
    const thread: Thread = {
      id,
      title: threadData.title,
      content: threadData.content,
      userId: threadData.userId,
      categoryId: threadData.categoryId,
      isPinned: false,
      isLocked: false,
      createdAt: timestamp,
      updatedAt: timestamp
    };
    
    this.threads.set(id, thread);
    return thread;
  }

  async updateThread(id: number, updates: Partial<Thread>): Promise<Thread> {
    const thread = this.threads.get(id);
    if (!thread) {
      throw new Error(`Thread with id ${id} not found`);
    }
    
    const updatedThread = { ...thread, ...updates, updatedAt: new Date() };
    this.threads.set(id, updatedThread);
    
    return updatedThread;
  }

  // Helper method to get thread with related data
  private async getThreadWithData(thread: Thread): Promise<ThreadWithData> {
    const author = await this.getUser(thread.userId);
    const category = await this.getCategory(thread.categoryId);
    
    if (!author || !category) {
      throw new Error("Thread references missing author or category");
    }
    
    const replyCount = Array.from(this.replies.values()).filter(
      (reply) => reply.threadId === thread.id
    ).length;
    
    const tags = await this.getTagsByThread(thread.id);
    
    return {
      ...thread,
      author,
      category,
      replyCount,
      tags
    };
  }

  // Reply methods
  async getRepliesByThread(threadId: number): Promise<ReplyWithData[]> {
    const replies = Array.from(this.replies.values()).filter(
      (reply) => reply.threadId === threadId
    );
    
    return Promise.all(
      replies.map(async (reply) => {
        return this.getReplyWithData(reply);
      })
    );
  }

  async getRepliesByUser(userId: number): Promise<ReplyWithData[]> {
    const replies = Array.from(this.replies.values()).filter(
      (reply) => reply.userId === userId
    );
    
    return Promise.all(
      replies.map(async (reply) => {
        return this.getReplyWithData(reply);
      })
    );
  }

  async createReply(replyData: InsertReply & { userId: number }): Promise<Reply> {
    const id = this.replyCounter++;
    const timestamp = new Date();
    
    const reply: Reply = {
      id,
      content: replyData.content,
      userId: replyData.userId,
      threadId: replyData.threadId,
      parentId: replyData.parentId,
      createdAt: timestamp,
      updatedAt: timestamp
    };
    
    this.replies.set(id, reply);
    return reply;
  }

  // Helper method to get reply with related data
  private async getReplyWithData(reply: Reply): Promise<ReplyWithData> {
    const author = await this.getUser(reply.userId);
    
    if (!author) {
      throw new Error("Reply references missing author");
    }
    
    const likeCount = Array.from(this.likes.entries()).filter(
      ([key, _]) => key.startsWith(`reply_${reply.id}_`)
    ).length;
    
    return {
      ...reply,
      author,
      likes: likeCount
    };
  }

  // Tag methods
  async getAllTags(): Promise<Tag[]> {
    return Array.from(this.tags.values());
  }

  async createTag(tagData: InsertTag): Promise<Tag> {
    const id = this.tagCounter++;
    
    const tag: Tag = {
      id,
      name: tagData.name
    };
    
    this.tags.set(id, tag);
    return tag;
  }

  async addTagToThread(threadId: number, tagId: number): Promise<void> {
    if (!this.threadTags.has(threadId)) {
      this.threadTags.set(threadId, new Set());
    }
    
    this.threadTags.get(threadId)?.add(tagId);
  }

  async getTagsByThread(threadId: number): Promise<Tag[]> {
    const tagIds = this.threadTags.get(threadId) || new Set();
    
    return Array.from(tagIds).map(id => {
      const tag = this.tags.get(id);
      if (!tag) {
        throw new Error(`Tag with id ${id} not found`);
      }
      return tag;
    });
  }

  // Like and report methods
  async likeThread(userId: number, threadId: number): Promise<void> {
    const key = `thread_${threadId}_${userId}`;
    this.likes.set(key, true);
  }

  async likeReply(userId: number, replyId: number): Promise<void> {
    const key = `reply_${replyId}_${userId}`;
    this.likes.set(key, true);
  }

  async createReport(reportData: InsertReport & { userId: number }): Promise<Report> {
    const id = this.reportCounter++;
    const timestamp = new Date();
    
    const report: Report = {
      id,
      userId: reportData.userId,
      reason: reportData.reason,
      threadId: reportData.threadId,
      replyId: reportData.replyId,
      createdAt: timestamp,
      resolved: false
    };
    
    this.reports.set(id, report);
    return report;
  }

  async getAllReports(): Promise<Report[]> {
    return Array.from(this.reports.values());
  }
}

export const storage = new MemStorage();
