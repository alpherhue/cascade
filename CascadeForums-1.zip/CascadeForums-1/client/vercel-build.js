const { execSync } = require('child_process');

// This script is called by Vercel when building the frontend
// It builds the client application using Vite

try {
  console.log('Building client application...');
  execSync('npm run build', { cwd: __dirname, stdio: 'inherit' });
  console.log('Client build completed successfully');
} catch (error) {
  console.error('Error building client:', error);
  process.exit(1);
}