import { Category } from "@shared/schema";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Card } from "@/components/ui/card";

interface CategoryCardProps {
  category: Category;
  threadCount?: number;
  todayPosts?: number;
  featured?: boolean;
}

export default function CategoryCard({ 
  category, 
  threadCount = 0, 
  todayPosts = 0,
  featured = false 
}: CategoryCardProps) {
  const { user } = useAuth();
  const { id, name, description, icon, color } = category;
  
  const linkUrl = user ? `/categories/${id}` : "/auth";
  
  if (featured) {
    return (
      <Card className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow overflow-hidden">
        <div className={`bg-${color} h-2`}></div>
        <div className="p-5">
          <div className="flex justify-between items-start">
            <div className="flex items-center">
              <i className={`ri-${icon} text-2xl text-${color} mr-3`}></i>
              <h3 className="font-semibold text-lg">{name}</h3>
            </div>
            <span className={`bg-${color.replace('500', '100')} dark:bg-${color.replace('500', '900')} text-${color.replace('500', '700')} dark:text-${color.replace('500', '200')} px-2 py-0.5 rounded-full text-xs font-medium`}>
              {threadCount > 0 ? `${threadCount} threads` : "New"}
            </span>
          </div>
          <p className="mt-2 text-gray-600 dark:text-gray-300 text-sm">{description}</p>
          <div className="mt-4 flex justify-between items-center">
            <div className="flex space-x-1 text-xs text-gray-500 dark:text-gray-400">
              <span><i className="ri-message-3-line mr-1"></i> {todayPosts} today</span>
            </div>
            <Link href={linkUrl} className={`text-${color} hover:text-${color.replace('500', '600')} dark:hover:text-${color.replace('500', '400')} text-sm font-medium`}>
              View Category
            </Link>
          </div>
        </div>
      </Card>
    );
  }
  
  return (
    <Card className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <i className={`ri-${icon} text-lg text-${color} mr-2`}></i>
          <h3 className="font-medium">{name}</h3>
        </div>
        <span className="text-xs text-gray-500 dark:text-gray-400">{threadCount > 0 ? threadCount : "-"}</span>
      </div>
      <p className="mt-2 text-sm text-gray-600 dark:text-gray-300 line-clamp-2">{description}</p>
      <div className="mt-2">
        <Link href={linkUrl} className={`text-${color} hover:text-${color.replace('500', '600')} text-xs font-medium`}>
          View Category
        </Link>
      </div>
    </Card>
  );
}
