import { ReplyWithData } from "server/storage";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { formatDistanceToNow } from "date-fns";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

interface ReplyItemProps {
  reply: ReplyWithData;
  threadId: number;
  replyNumber: number;
  isOP?: boolean;
  childReplies?: ReplyWithData[];
}

const replySchema = z.object({
  content: z.string().min(3, "Reply must be at least 3 characters"),
});

type ReplyFormData = z.infer<typeof replySchema>;

export default function ReplyItem({ 
  reply, 
  threadId,
  replyNumber,
  isOP = false,
  childReplies = []
}: ReplyItemProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isReplying, setIsReplying] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const form = useForm<ReplyFormData>({
    resolver: zodResolver(replySchema),
    defaultValues: {
      content: "",
    },
  });
  
  const { id, content, author, createdAt, likes } = reply;
  const formattedDate = formatDistanceToNow(new Date(createdAt), { addSuffix: true });
  
  const handleLike = async () => {
    if (!user) return;
    
    try {
      await apiRequest("POST", `/api/replies/${id}/like`, {});
      queryClient.invalidateQueries({ queryKey: [`/api/replies?threadId=${threadId}`] });
      toast({ title: "Reply liked" });
    } catch (error) {
      toast({ 
        title: "Error", 
        description: "Could not like this reply", 
        variant: "destructive" 
      });
    }
  };
  
  const handleReport = async () => {
    if (!user) return;
    
    try {
      await apiRequest("POST", "/api/reports", {
        replyId: id,
        reason: "Reported by user",
      });
      toast({ title: "Report submitted", description: "Thank you for your feedback" });
    } catch (error) {
      toast({ 
        title: "Error", 
        description: "Could not submit report", 
        variant: "destructive" 
      });
    }
  };
  
  const onSubmitReply = async (data: ReplyFormData) => {
    if (!user) return;
    
    setIsSubmitting(true);
    try {
      await apiRequest("POST", "/api/replies", {
        content: data.content,
        threadId: threadId,
        parentId: id,
      });
      
      queryClient.invalidateQueries({ queryKey: [`/api/replies?threadId=${threadId}`] });
      form.reset();
      setIsReplying(false);
      toast({ title: "Reply posted" });
    } catch (error) {
      toast({ 
        title: "Error", 
        description: "Could not post reply", 
        variant: "destructive" 
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4 mb-4">
      <div className="flex items-start">
        <div className="rounded-full bg-gray-200 dark:bg-gray-700 w-8 h-8 flex items-center justify-center mr-3 flex-shrink-0">
          <i className="ri-user-line"></i>
        </div>
        <div className="flex-grow">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center">
              <span className="font-medium mr-2">{author.displayName}</span>
              {isOP && (
                <span className="bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 text-xs px-1.5 py-0.5 rounded-full">OP</span>
              )}
              <span className="ml-2 text-xs text-gray-500 dark:text-gray-400">{formattedDate}</span>
            </div>
            <div className="text-xs text-gray-500 dark:text-gray-400">#{replyNumber}</div>
          </div>
          
          <div className="prose dark:prose-invert max-w-none text-sm mb-3">
            {content}
          </div>
          
          <div className="flex items-center space-x-4 text-xs">
            <button 
              className="flex items-center text-gray-500 dark:text-gray-400 hover:text-primary-500 dark:hover:text-primary-400"
              onClick={handleLike}
            >
              <i className="ri-thumb-up-line mr-1"></i> {likes}
            </button>
            <button 
              className="flex items-center text-gray-500 dark:text-gray-400 hover:text-primary-500 dark:hover:text-primary-400"
              onClick={() => setIsReplying(prev => !prev)}
            >
              <i className="ri-reply-line mr-1"></i> Reply
            </button>
            <button 
              className="flex items-center text-gray-500 dark:text-gray-400 hover:text-red-500 dark:hover:text-red-400"
              onClick={handleReport}
            >
              <i className="ri-flag-line mr-1"></i> Report
            </button>
          </div>
          
          {isReplying && (
            <div className="mt-4">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmitReply)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="content"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Textarea 
                            placeholder="Write your reply..." 
                            className="min-h-[100px]" 
                            {...field} 
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex justify-end space-x-2">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setIsReplying(false)}
                      disabled={isSubmitting}
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Posting...
                        </>
                      ) : (
                        "Post Reply"
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </div>
          )}
        </div>
      </div>
      
      {childReplies && childReplies.length > 0 && (
        <div className="ml-11 mt-4 pl-4 reply-indent">
          {childReplies.map((childReply, index) => (
            <div key={childReply.id} className="flex items-start mb-4 last:mb-0">
              <div className="rounded-full bg-gray-200 dark:bg-gray-700 w-7 h-7 flex items-center justify-center mr-3 flex-shrink-0">
                <i className="ri-user-line text-sm"></i>
              </div>
              <div className="flex-grow">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center">
                    <span className="font-medium mr-2">{childReply.author.displayName}</span>
                    {childReply.author.id === reply.author.id && (
                      <span className="bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 text-xs px-1.5 py-0.5 rounded-full">OP</span>
                    )}
                    <span className="ml-2 text-xs text-gray-500 dark:text-gray-400">
                      {formatDistanceToNow(new Date(childReply.createdAt), { addSuffix: true })}
                    </span>
                  </div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">
                    #{replyNumber}.{index + 1}
                  </div>
                </div>
                
                <div className="prose dark:prose-invert max-w-none text-sm mb-3">
                  {childReply.content}
                </div>
                
                <div className="flex items-center space-x-4 text-xs">
                  <button 
                    className="flex items-center text-gray-500 dark:text-gray-400 hover:text-primary-500 dark:hover:text-primary-400"
                    onClick={async () => {
                      try {
                        await apiRequest("POST", `/api/replies/${childReply.id}/like`, {});
                        queryClient.invalidateQueries({ queryKey: [`/api/replies?threadId=${threadId}`] });
                      } catch (error) {
                        toast({ 
                          title: "Error", 
                          description: "Could not like this reply",
                          variant: "destructive" 
                        });
                      }
                    }}
                  >
                    <i className="ri-thumb-up-line mr-1"></i> {childReply.likes}
                  </button>
                  <button 
                    className="flex items-center text-gray-500 dark:text-gray-400 hover:text-red-500 dark:hover:text-red-400"
                    onClick={async () => {
                      try {
                        await apiRequest("POST", "/api/reports", {
                          replyId: childReply.id,
                          reason: "Reported by user",
                        });
                        toast({ 
                          title: "Report submitted", 
                          description: "Thank you for your feedback" 
                        });
                      } catch (error) {
                        toast({ 
                          title: "Error", 
                          description: "Could not submit report", 
                          variant: "destructive" 
                        });
                      }
                    }}
                  >
                    <i className="ri-flag-line mr-1"></i> Report
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
