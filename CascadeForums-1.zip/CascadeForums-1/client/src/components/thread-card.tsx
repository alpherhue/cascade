import { ThreadWithData } from "server/storage";
import { Link } from "wouter";
import { formatDistanceToNow } from "date-fns";

interface ThreadCardProps {
  thread: ThreadWithData;
}

export default function ThreadCard({ thread }: ThreadCardProps) {
  const {
    id,
    title,
    content,
    author,
    category,
    createdAt,
    isPinned,
    isLocked,
    replyCount,
    tags
  } = thread;
  
  const formattedDate = formatDistanceToNow(new Date(createdAt), { addSuffix: true });
  
  // Truncate content for preview
  const previewContent = content.length > 200 
    ? content.substring(0, 200) + "..." 
    : content;
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div className="flex-grow">
          <div className="flex items-center space-x-2 mb-1">
            {isPinned && (
              <span className="bg-primary-100 dark:bg-primary-900 text-primary-700 dark:text-primary-300 text-xs px-2 py-0.5 rounded-full">
                Pinned
              </span>
            )}
            
            {isLocked && (
              <span className="bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300 text-xs px-2 py-0.5 rounded-full">
                Locked
              </span>
            )}
            
            <span className="text-xs text-gray-500 dark:text-gray-400">{category.name}</span>
          </div>
          
          <Link href={`/threads/${id}`}>
            <h3 className="font-semibold text-lg hover:text-primary-500 transition-colors cursor-pointer">
              {title}
            </h3>
          </Link>
          
          <div className="mt-2 flex items-center text-sm">
            <div className="flex items-center text-gray-500 dark:text-gray-400">
              <div className="rounded-full bg-gray-200 dark:bg-gray-700 w-5 h-5 flex items-center justify-center mr-2">
                <i className="ri-user-line text-xs"></i>
              </div>
              <span>{author.displayName}</span>
            </div>
            <span className="mx-2 text-gray-300 dark:text-gray-600">•</span>
            <span className="text-gray-500 dark:text-gray-400">{formattedDate}</span>
          </div>
        </div>
        <div className="flex flex-col items-center min-w-[70px] text-center">
          <span className="text-2xl font-semibold text-gray-700 dark:text-gray-300">{replyCount}</span>
          <span className="text-xs text-gray-500 dark:text-gray-400">replies</span>
        </div>
      </div>
      
      <p className="mt-3 text-gray-600 dark:text-gray-300 text-sm line-clamp-2">
        {previewContent}
      </p>
      
      {tags && tags.length > 0 && (
        <div className="mt-4 flex flex-wrap items-center gap-2 text-xs">
          {tags.map(tag => (
            <div key={tag.id} className="bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded-full text-gray-600 dark:text-gray-300">
              {tag.name}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
