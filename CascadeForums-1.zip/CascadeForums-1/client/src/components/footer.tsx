import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-white dark:bg-gray-800 shadow-sm border-t border-gray-200 dark:border-gray-700 mt-12">
      <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <i className="ri-discuss-line text-2xl text-primary-500 mr-2"></i>
            <span className="font-bold text-xl">Cascade Forums</span>
          </div>
          <nav className="flex flex-wrap gap-4 justify-center text-sm text-gray-500 dark:text-gray-400">
            <Link href="/" className="hover:text-gray-700 dark:hover:text-gray-300">
              Home
            </Link>
            <Link href="/" className="hover:text-gray-700 dark:hover:text-gray-300">
              About
            </Link>
            <Link href="/" className="hover:text-gray-700 dark:hover:text-gray-300">
              Terms of Service
            </Link>
            <Link href="/" className="hover:text-gray-700 dark:hover:text-gray-300">
              Privacy Policy
            </Link>
            <Link href="/" className="hover:text-gray-700 dark:hover:text-gray-300">
              Contact
            </Link>
          </nav>
        </div>
        <div className="mt-8 text-center text-sm text-gray-500 dark:text-gray-400">
          &copy; {new Date().getFullYear()} Cascade Forums. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
