import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useTheme } from "@/components/theme-provider";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const { user, logoutMutation } = useAuth();
  const { theme, setTheme } = useTheme();
  const [, navigate] = useLocation();
  
  // Close mobile menu when location changes
  const closeMenu = () => setIsOpen(false);
  
  const handleLogout = () => {
    logoutMutation.mutate();
    navigate("/");
  };
  
  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };
  
  return (
    <header className="bg-white dark:bg-gray-800 shadow sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center h-16">
        <div className="flex items-center space-x-4">
          <Link href="/" className="flex items-center">
            <i className="ri-discuss-line text-2xl text-primary-500 mr-2"></i>
            <span className="font-bold text-xl">Cascade Forums</span>
          </Link>
          <nav className="hidden md:flex space-x-4">
            <Link href="/" className="px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-700">
              Home
            </Link>
            <Link href="/" className="px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-700">
              Categories
            </Link>
            {user && (
              <>
                <Link href={`/profile/${user.id}`} className="px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-700">
                  My Profile
                </Link>
              </>
            )}
          </nav>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Input
              type="text"
              placeholder="Search..."
              className="py-1.5 pl-8 pr-2 text-sm bg-gray-100 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600 focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500 dark:focus:border-primary-500 w-40 md:w-64"
            />
            <i className="ri-search-line absolute left-2.5 top-2 text-gray-400"></i>
          </div>
          
          <button
            onClick={toggleTheme}
            className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none"
          >
            {theme === "dark" ? (
              <i className="ri-moon-line text-xl"></i>
            ) : (
              <i className="ri-sun-line text-xl"></i>
            )}
          </button>
          
          {!user ? (
            <div className="hidden md:flex space-x-2">
              <Link href="/auth">
                <Button variant="outline" size="sm">
                  Log In
                </Button>
              </Link>
              <Link href="/auth">
                <Button size="sm">Sign Up</Button>
              </Link>
            </div>
          ) : (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center space-x-2">
                  <span className="text-sm font-medium hidden md:inline">{user.displayName}</span>
                  <div className="rounded-full bg-gray-200 dark:bg-gray-700 overflow-hidden flex items-center justify-center w-8 h-8">
                    <i className="ri-user-3-line"></i>
                  </div>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <Link href={`/profile/${user.id}`}>
                  <DropdownMenuItem>
                    <i className="ri-user-line mr-2"></i> Profile
                  </DropdownMenuItem>
                </Link>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <i className="ri-logout-box-line mr-2"></i> Log out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
          
          <button
            className="block md:hidden p-1 rounded-md focus:outline-none hover:bg-gray-100 dark:hover:bg-gray-700"
            onClick={() => setIsOpen(!isOpen)}
          >
            <i className={isOpen ? "ri-close-line text-xl" : "ri-menu-line text-xl"}></i>
          </button>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 p-4">
          <nav className="flex flex-col space-y-2">
            <Link 
              href="/" 
              className="px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-700"
              onClick={closeMenu}
            >
              Home
            </Link>
            <Link 
              href="/" 
              className="px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-700"
              onClick={closeMenu}
            >
              Categories
            </Link>
            {user ? (
              <>
                <Link 
                  href={`/profile/${user.id}`} 
                  className="px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-700"
                  onClick={closeMenu}
                >
                  My Profile
                </Link>
                <button 
                  className="px-3 py-2 rounded-md text-sm font-medium text-red-600 hover:bg-gray-100 dark:text-red-400 dark:hover:bg-gray-700 text-left"
                  onClick={() => {
                    handleLogout();
                    closeMenu();
                  }}
                >
                  Log Out
                </button>
              </>
            ) : (
              <div className="flex flex-col space-y-2 mt-2">
                <Link href="/auth" onClick={closeMenu}>
                  <Button variant="outline" className="w-full">
                    Log In
                  </Button>
                </Link>
                <Link href="/auth" onClick={closeMenu}>
                  <Button className="w-full">Sign Up</Button>
                </Link>
              </div>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
