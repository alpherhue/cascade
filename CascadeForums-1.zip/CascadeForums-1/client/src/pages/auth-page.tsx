import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import AuthForms from "@/components/auth-forms";

export default function AuthPage() {
  const { user, isLoading } = useAuth();
  const [, navigate] = useLocation();
  
  // Redirect to home if already logged in
  useEffect(() => {
    if (user && !isLoading) {
      navigate("/");
    }
  }, [user, isLoading, navigate]);
  
  // Don't render anything while checking authentication status
  if (isLoading) {
    return null;
  }
  
  return (
    <div className="flex flex-col md:flex-row gap-8 max-w-6xl mx-auto py-8">
      {/* Hero section */}
      <div className="md:w-1/2 p-6">
        <h1 className="text-3xl font-bold mb-6">Join the Conversation at Cascade Forums</h1>
        
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4">Why Join Our Community?</h2>
          <ul className="space-y-3">
            <li className="flex items-start">
              <i className="ri-check-line text-green-500 mr-2 mt-1"></i>
              <span>Access to all discussion threads and categories</span>
            </li>
            <li className="flex items-start">
              <i className="ri-check-line text-green-500 mr-2 mt-1"></i>
              <span>Create your own threads and participate in discussions</span>
            </li>
            <li className="flex items-start">
              <i className="ri-check-line text-green-500 mr-2 mt-1"></i>
              <span>Maintain anonymity with auto-generated display names</span>
            </li>
            <li className="flex items-start">
              <i className="ri-check-line text-green-500 mr-2 mt-1"></i>
              <span>Get real-time updates on threads you're following</span>
            </li>
          </ul>
        </div>
        
        <div className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
          <h3 className="font-semibold mb-2 flex items-center">
            <i className="ri-shield-check-line text-primary-500 mr-2"></i>
            Privacy Commitment
          </h3>
          <p className="text-sm text-gray-600 dark:text-gray-300">
            We respect your privacy. Your email is only used for account verification and notifications. 
            Your discussions are protected by our strong anonymity features.
          </p>
        </div>
      </div>
      
      {/* Auth forms */}
      <div className="md:w-1/2">
        <AuthForms />
      </div>
    </div>
  );
}
