import { useState, useEffect } from "react";
import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Category } from "@shared/schema";
import { ThreadWithData } from "server/storage";
import ThreadCard from "@/components/thread-card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Loader2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const threadSchema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters"),
  content: z.string().min(20, "Content must be at least 20 characters"),
});

type ThreadFormData = z.infer<typeof threadSchema>;

export default function CategoryPage() {
  const [, params] = useRoute<{ id: string }>("/categories/:id");
  const categoryId = params?.id ? parseInt(params.id) : 0;
  const { toast } = useToast();
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  
  // Setup WebSocket for real-time updates
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);
    
    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      if (data.type === "thread_created" && data.data.categoryId === categoryId) {
        // Invalidate query to refresh threads
        queryClient.invalidateQueries({ queryKey: [`/api/threads?categoryId=${categoryId}`] });
      }
    };
    
    return () => {
      socket.close();
    };
  }, [categoryId]);
  
  // Fetch category details
  const { 
    data: category, 
    isLoading: isCategoryLoading, 
    error: categoryError 
  } = useQuery<Category>({
    queryKey: [`/api/categories/${categoryId}`],
    enabled: !!categoryId,
  });
  
  // Fetch threads
  const { 
    data: threads, 
    isLoading: isThreadsLoading, 
    error: threadsError 
  } = useQuery<ThreadWithData[]>({
    queryKey: [`/api/threads?categoryId=${categoryId}`],
    enabled: !!categoryId,
  });
  
  // Thread creation form
  const form = useForm<ThreadFormData>({
    resolver: zodResolver(threadSchema),
    defaultValues: {
      title: "",
      content: "",
    },
  });
  
  const onSubmit = async (data: ThreadFormData) => {
    try {
      await apiRequest("POST", "/api/threads", {
        ...data,
        categoryId,
      });
      
      queryClient.invalidateQueries({ queryKey: [`/api/threads?categoryId=${categoryId}`] });
      toast({ title: "Thread created successfully" });
      form.reset();
      setCreateDialogOpen(false);
    } catch (error) {
      toast({ 
        title: "Failed to create thread", 
        description: "Please try again",
        variant: "destructive" 
      });
    }
  };
  
  // Loading state
  if (isCategoryLoading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center mb-2">
          <Skeleton className="h-4 w-32" />
        </div>
        <div className="flex items-center">
          <Skeleton className="h-8 w-8 rounded-md mr-3" />
          <Skeleton className="h-8 w-64" />
        </div>
        <Skeleton className="h-4 w-full max-w-md" />
        
        <div className="mt-8 space-y-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
              <div className="flex justify-between">
                <div className="space-y-2 w-full">
                  <div className="flex">
                    <Skeleton className="h-4 w-16 rounded-full mr-2" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                  <Skeleton className="h-6 w-3/4" />
                  <div className="flex items-center">
                    <Skeleton className="h-5 w-5 rounded-full mr-2" />
                    <Skeleton className="h-4 w-32" />
                  </div>
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-5/6" />
                </div>
                <Skeleton className="h-12 w-16 rounded-md" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
  
  // Error state
  if (categoryError || threadsError) {
    return (
      <div className="bg-red-50 dark:bg-red-900/20 text-red-800 dark:text-red-200 p-4 rounded-md">
        <p>Error loading content. Please try again later.</p>
        <Link href="/">
          <Button variant="outline" className="mt-4">
            Return to Home
          </Button>
        </Link>
      </div>
    );
  }
  
  // No category found
  if (!category) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">Category Not Found</h2>
        <p className="mb-6">The category you're looking for doesn't exist or has been removed.</p>
        <Link href="/">
          <Button>Return to Home</Button>
        </Link>
      </div>
    );
  }
  
  return (
    <div>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div>
          <div className="flex items-center mb-2">
            <Link href="/" className="text-sm text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 flex items-center">
              <i className="ri-arrow-left-line mr-1"></i> Back to Categories
            </Link>
          </div>
          <div className="flex items-center">
            <i className={`ri-${category.icon} text-2xl text-${category.color} mr-3`}></i>
            <h1 className="text-2xl font-bold">{category.name}</h1>
          </div>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{category.description}</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" className="text-sm">
            <i className="ri-filter-3-line mr-1"></i> Filter
          </Button>
          <Button variant="outline" size="sm" className="text-sm">
            <i className="ri-sort-desc-line mr-1"></i> Sort
          </Button>
          
          <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="text-sm">
                <i className="ri-add-line mr-1"></i> New Thread
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[550px]">
              <DialogHeader>
                <DialogTitle>Create New Thread</DialogTitle>
                <DialogDescription>
                  Post a new discussion thread in {category.name}.
                </DialogDescription>
              </DialogHeader>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 mt-4">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Thread Title</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Enter a descriptive title for your thread"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="content"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Content</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Describe what you want to discuss..."
                            className="min-h-[200px]"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex justify-end space-x-2 pt-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setCreateDialogOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit"
                      disabled={form.formState.isSubmitting}
                    >
                      {form.formState.isSubmitting ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Creating...
                        </>
                      ) : (
                        "Create Thread"
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      {/* Thread list */}
      <div className="space-y-4">
        {isThreadsLoading ? (
          <div className="flex justify-center my-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary-500" />
          </div>
        ) : threads && threads.length > 0 ? (
          threads.map((thread) => (
            <ThreadCard key={thread.id} thread={thread} />
          ))
        ) : (
          <div className="bg-white dark:bg-gray-800 rounded-lg p-8 text-center border border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-medium mb-2">No threads yet</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              Be the first to start a discussion in this category!
            </p>
            <Button onClick={() => setCreateDialogOpen(true)}>
              <i className="ri-add-line mr-1"></i> Create Thread
            </Button>
          </div>
        )}
      </div>
      
      {/* Pagination - static for now */}
      {threads && threads.length > 0 && (
        <div className="mt-8 flex justify-center">
          <div className="flex space-x-1">
            <Button variant="outline" size="sm" className="px-3 py-1">
              <i className="ri-arrow-left-s-line"></i>
            </Button>
            <Button size="sm" className="px-3 py-1">1</Button>
            <Button variant="outline" size="sm" className="px-3 py-1">2</Button>
            <Button variant="outline" size="sm" className="px-3 py-1">3</Button>
            <Button variant="outline" size="sm" disabled className="px-3 py-1">...</Button>
            <Button variant="outline" size="sm" className="px-3 py-1">
              <i className="ri-arrow-right-s-line"></i>
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
