import { useState, useEffect } from "react";
import { useRoute, Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ThreadWithData } from "server/storage";
import { ReplyWithData } from "server/storage";
import { formatDistanceToNow } from "date-fns";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { Skeleton } from "@/components/ui/skeleton";
import { Loader2, Flag, ThumbsUp, Bookmark } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import ReplyItem from "@/components/reply-item";

const replySchema = z.object({
  content: z.string().min(10, "Reply must be at least 10 characters"),
});

type ReplyFormData = z.infer<typeof replySchema>;

export default function ThreadPage() {
  const [, params] = useRoute<{ id: string }>("/threads/:id");
  const threadId = params?.id ? parseInt(params.id) : 0;
  const { user } = useAuth();
  const { toast } = useToast();
  const [visibleReplies, setVisibleReplies] = useState(10);

  // Setup WebSocket for real-time updates
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);
    
    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      if (data.type === "reply_created" && data.data.threadId === threadId) {
        // Invalidate query to refresh replies
        queryClient.invalidateQueries({ queryKey: [`/api/replies?threadId=${threadId}`] });
      }
      
      if (data.type === "thread_liked" && data.data.threadId === threadId) {
        // Invalidate thread query
        queryClient.invalidateQueries({ queryKey: [`/api/threads/${threadId}`] });
      }
    };
    
    return () => {
      socket.close();
    };
  }, [threadId]);

  // Fetch thread details
  const { 
    data: thread, 
    isLoading: isThreadLoading, 
    error: threadError 
  } = useQuery<ThreadWithData>({
    queryKey: [`/api/threads/${threadId}`],
    enabled: !!threadId,
  });

  // Fetch replies
  const { 
    data: replies, 
    isLoading: isRepliesLoading,
    error: repliesError
  } = useQuery<ReplyWithData[]>({
    queryKey: [`/api/replies?threadId=${threadId}`],
    enabled: !!threadId,
  });

  // Reply form
  const form = useForm<ReplyFormData>({
    resolver: zodResolver(replySchema),
    defaultValues: {
      content: "",
    },
  });

  // Post reply mutation
  const replyMutation = useMutation({
    mutationFn: async (data: ReplyFormData) => {
      return await apiRequest("POST", "/api/replies", {
        content: data.content,
        threadId,
      });
    },
    onSuccess: () => {
      form.reset();
      toast({ title: "Reply posted successfully" });
      queryClient.invalidateQueries({ queryKey: [`/api/replies?threadId=${threadId}`] });
    },
    onError: () => {
      toast({ 
        title: "Failed to post reply", 
        description: "Please try again later", 
        variant: "destructive" 
      });
    },
  });

  // Handle form submission
  const onSubmit = (data: ReplyFormData) => {
    replyMutation.mutate(data);
  };

  // Handle thread like
  const handleLikeThread = async () => {
    if (!user || !thread) return;
    
    try {
      await apiRequest("POST", `/api/threads/${threadId}/like`, {});
      queryClient.invalidateQueries({ queryKey: [`/api/threads/${threadId}`] });
      toast({ title: "Thread liked" });
    } catch (error) {
      toast({ 
        title: "Error", 
        description: "Could not like this thread",
        variant: "destructive"
      });
    }
  };

  // Handle thread report
  const handleReportThread = async () => {
    if (!user || !thread) return;
    
    try {
      await apiRequest("POST", "/api/reports", {
        threadId,
        reason: "Reported by user",
      });
      toast({ 
        title: "Report submitted", 
        description: "Thank you for your feedback" 
      });
    } catch (error) {
      toast({ 
        title: "Error", 
        description: "Could not submit report",
        variant: "destructive"
      });
    }
  };

  // Loading state
  if (isThreadLoading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center mb-2">
          <Skeleton className="h-4 w-32" />
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-5 mb-4">
          <div className="flex space-x-2 mb-2">
            <Skeleton className="h-4 w-20 rounded-full" />
            <Skeleton className="h-4 w-16" />
          </div>
          <Skeleton className="h-8 w-3/4 mb-4" />
          
          <div className="flex items-center mb-4">
            <Skeleton className="h-8 w-8 rounded-full mr-2" />
            <div>
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-3 w-24 mt-1" />
            </div>
          </div>
          
          <div className="space-y-2 mb-4">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-4 w-5/6" />
            <Skeleton className="h-4 w-full" />
          </div>
          
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Skeleton className="h-6 w-16 rounded-full" />
            <Skeleton className="h-6 w-24 rounded-full" />
            <Skeleton className="h-6 w-20 rounded-full" />
          </div>
        </div>
        
        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <Skeleton className="h-6 w-32" />
            <Skeleton className="h-8 w-24" />
          </div>
          
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4">
                <div className="flex items-start">
                  <Skeleton className="h-8 w-8 rounded-full mr-3 flex-shrink-0" />
                  <div className="flex-grow">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center">
                        <Skeleton className="h-4 w-32 mr-2" />
                        <Skeleton className="h-3 w-24" />
                      </div>
                      <Skeleton className="h-3 w-6" />
                    </div>
                    <div className="space-y-2 mb-3">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-3/4" />
                    </div>
                    <div className="flex items-center space-x-4">
                      <Skeleton className="h-4 w-16" />
                      <Skeleton className="h-4 w-16" />
                      <Skeleton className="h-4 w-16" />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Error state
  if (threadError || repliesError) {
    return (
      <div className="bg-red-50 dark:bg-red-900/20 text-red-800 dark:text-red-200 p-4 rounded-md">
        <p>Error loading content. Please try again later.</p>
        <Link href="/">
          <Button variant="outline" className="mt-4">
            Return to Home
          </Button>
        </Link>
      </div>
    );
  }

  // No thread found
  if (!thread) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">Thread Not Found</h2>
        <p className="mb-6">The thread you're looking for doesn't exist or has been removed.</p>
        <Link href="/">
          <Button>Return to Home</Button>
        </Link>
      </div>
    );
  }

  // Process the replies to organize them into a tree structure
  const mainReplies: ReplyWithData[] = [];
  const childReplies: Record<number, ReplyWithData[]> = {};

  if (replies) {
    replies.forEach(reply => {
      if (!reply.parentId) {
        mainReplies.push(reply);
      } else {
        if (!childReplies[reply.parentId]) {
          childReplies[reply.parentId] = [];
        }
        childReplies[reply.parentId].push(reply);
      }
    });
  }

  const visibleMainReplies = mainReplies.slice(0, visibleReplies);
  const hasMoreReplies = mainReplies.length > visibleReplies;

  const formattedDate = thread.createdAt 
    ? formatDistanceToNow(new Date(thread.createdAt), { addSuffix: true })
    : "recently";

  return (
    <div className="mb-6">
      <div className="flex items-center mb-2">
        <Link 
          href={`/categories/${thread.categoryId}`} 
          className="text-sm text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 flex items-center"
        >
          <i className="ri-arrow-left-line mr-1"></i> Back to {thread.category.name}
        </Link>
      </div>
      
      {/* Thread header */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-5 mb-4">
        <div className="flex items-center space-x-2 mb-2">
          {thread.isPinned && (
            <span className="bg-primary-100 dark:bg-primary-900 text-primary-700 dark:text-primary-300 text-xs px-2 py-0.5 rounded-full">
              Pinned
            </span>
          )}
          {thread.isLocked && (
            <span className="bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300 text-xs px-2 py-0.5 rounded-full">
              Locked
            </span>
          )}
          <span className="text-xs text-gray-500 dark:text-gray-400">{thread.category.name}</span>
        </div>
        
        <h1 className="text-2xl font-bold mb-4">{thread.title}</h1>
        
        <div className="flex items-center mb-4">
          <div className="rounded-full bg-gray-200 dark:bg-gray-700 w-8 h-8 flex items-center justify-center mr-2">
            <i className="ri-user-line"></i>
          </div>
          <div>
            <div className="font-medium">{thread.author.displayName}</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Posted {formattedDate}</div>
          </div>
        </div>
        
        <div className="prose dark:prose-invert max-w-none mb-4">
          <p>{thread.content}</p>
        </div>
        
        {thread.tags && thread.tags.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 text-xs mb-4">
            {thread.tags.map(tag => (
              <div key={tag.id} className="bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded-full text-gray-600 dark:text-gray-300">
                {tag.name}
              </div>
            ))}
          </div>
        )}
        
        <div className="flex items-center space-x-4 text-sm">
          <button 
            className="flex items-center text-gray-500 dark:text-gray-400 hover:text-primary-500 dark:hover:text-primary-400"
            onClick={handleLikeThread}
            disabled={thread.isLocked}
          >
            <ThumbsUp className="mr-1 h-4 w-4" /> 15
          </button>
          <button 
            className="flex items-center text-gray-500 dark:text-gray-400 hover:text-primary-500 dark:hover:text-primary-400"
          >
            <Bookmark className="mr-1 h-4 w-4" /> Save
          </button>
          <button 
            className="flex items-center text-gray-500 dark:text-gray-400 hover:text-red-500 dark:hover:text-red-400"
            onClick={handleReportThread}
          >
            <Flag className="mr-1 h-4 w-4" /> Report
          </button>
        </div>
      </div>
      
      {/* Replies section */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">
            Replies ({replies ? replies.length : 0})
          </h2>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" className="text-sm">
              <i className="ri-sort-desc-line mr-1"></i> Newest
            </Button>
          </div>
        </div>
        
        {isRepliesLoading ? (
          <div className="flex justify-center my-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary-500" />
          </div>
        ) : replies && visibleMainReplies.length > 0 ? (
          <>
            {visibleMainReplies.map((reply, index) => (
              <ReplyItem 
                key={reply.id} 
                reply={reply} 
                threadId={threadId}
                replyNumber={index + 1}
                isOP={reply.author.id === thread.author.id}
                childReplies={childReplies[reply.id] || []}
              />
            ))}
            
            {hasMoreReplies && (
              <button 
                className="w-full py-2 text-sm text-primary-500 hover:text-primary-600 dark:hover:text-primary-400 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg mt-4"
                onClick={() => setVisibleReplies(prev => prev + 10)}
              >
                Load more replies
              </button>
            )}
          </>
        ) : (
          <div className="bg-white dark:bg-gray-800 rounded-lg p-8 text-center border border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-medium mb-2">No replies yet</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              Be the first to reply to this thread!
            </p>
          </div>
        )}
      </div>
      
      {/* Reply form */}
      {!thread.isLocked ? (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4">
          <h3 className="font-medium mb-3">Post a reply</h3>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="content"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Textarea 
                        placeholder="Write your reply..." 
                        className="min-h-[120px]" 
                        {...field} 
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <div className="flex justify-between items-center">
                <div className="text-sm text-gray-500 dark:text-gray-400">
                  Supports Markdown formatting
                </div>
                <Button 
                  type="submit"
                  disabled={replyMutation.isPending}
                >
                  {replyMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Posting...
                    </>
                  ) : (
                    "Post Reply"
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      ) : (
        <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4 text-yellow-800 dark:text-yellow-200">
          <div className="flex items-center">
            <i className="ri-lock-line mr-2 text-lg"></i>
            <span>This thread is locked. No new replies can be posted.</span>
          </div>
        </div>
      )}
    </div>
  );
}
