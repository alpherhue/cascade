import { useEffect, useState } from "react";
import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";
import { User } from "@shared/schema";
import { ThreadWithData, ReplyWithData } from "server/storage";
import { useAuth } from "@/hooks/use-auth";

export default function ProfilePage() {
  const [, params] = useRoute<{ id: string }>("/profile/:id");
  const userId = params?.id ? parseInt(params.id) : 0;
  const { user: currentUser } = useAuth();
  const isOwnProfile = currentUser?.id === userId;
  
  // Fetch user details
  const { 
    data: user, 
    isLoading: isUserLoading, 
    error: userError 
  } = useQuery<User>({
    queryKey: [`/api/user`],
    enabled: isOwnProfile,
  });
  
  // Fetch user threads
  const { 
    data: threads, 
    isLoading: isThreadsLoading, 
    error: threadsError 
  } = useQuery<ThreadWithData[]>({
    queryKey: [`/api/users/${userId}/threads`],
    enabled: !!userId,
  });
  
  // Fetch user replies
  const { 
    data: replies, 
    isLoading: isRepliesLoading, 
    error: repliesError 
  } = useQuery<ReplyWithData[]>({
    queryKey: [`/api/users/${userId}/replies`],
    enabled: !!userId,
  });
  
  // Prepare display data
  const profileData = isOwnProfile ? currentUser : user;
  const displayName = profileData?.displayName || "User";
  const joinDate = profileData?.createdAt 
    ? new Date(profileData.createdAt)
    : new Date();
  
  const threadCount = threads?.length || 0;
  const replyCount = replies?.length || 0;
  
  // Calculate total likes received
  const likesReceived = replies?.reduce((total, reply) => total + reply.likes, 0) || 0;
  
  // Calculate days active (from join date to now)
  const daysActive = Math.ceil((new Date().getTime() - joinDate.getTime()) / (1000 * 3600 * 24));
  
  // Loading state
  if ((isUserLoading && isOwnProfile) || isThreadsLoading || isRepliesLoading) {
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center space-x-4">
            <Skeleton className="w-16 h-16 rounded-full" />
            <div>
              <Skeleton className="h-8 w-40" />
              <Skeleton className="h-4 w-32 mt-2" />
            </div>
          </div>
          
          <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-4">
            <Skeleton className="h-24 rounded-lg" />
            <Skeleton className="h-24 rounded-lg" />
            <Skeleton className="h-24 rounded-lg" />
            <Skeleton className="h-24 rounded-lg" />
          </div>
        </div>
        
        <div>
          <div className="flex justify-between items-center mb-4">
            <Skeleton className="h-6 w-36" />
            <Skeleton className="h-4 w-16" />
          </div>
          
          <div className="space-y-4">
            <Skeleton className="h-28 rounded-lg" />
            <Skeleton className="h-28 rounded-lg" />
          </div>
        </div>
        
        <div>
          <div className="flex justify-between items-center mb-4">
            <Skeleton className="h-6 w-36" />
            <Skeleton className="h-4 w-16" />
          </div>
          
          <div className="space-y-4">
            <Skeleton className="h-28 rounded-lg" />
            <Skeleton className="h-28 rounded-lg" />
          </div>
        </div>
      </div>
    );
  }
  
  // Error state
  if (userError || threadsError || repliesError) {
    return (
      <div className="bg-red-50 dark:bg-red-900/20 text-red-800 dark:text-red-200 p-4 rounded-md">
        <p>Error loading profile data. Please try again later.</p>
        <Link href="/">
          <Button variant="outline" className="mt-4">
            Return to Home
          </Button>
        </Link>
      </div>
    );
  }
  
  return (
    <div>
      {/* User Profile Header */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 mb-6">
        <div className="flex items-center space-x-4">
          <div className="rounded-full bg-gray-200 dark:bg-gray-700 w-16 h-16 flex items-center justify-center">
            <i className="ri-user-3-line text-2xl"></i>
          </div>
          <div>
            <h1 className="text-2xl font-bold">{displayName}</h1>
            <p className="text-gray-500 dark:text-gray-400">
              Member since {joinDate.toLocaleDateString("en-US", { month: "long", year: "numeric" })}
            </p>
          </div>
        </div>
        
        <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
          <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
            <div className="text-2xl font-bold">{threadCount}</div>
            <div className="text-sm text-gray-500 dark:text-gray-400">Threads</div>
          </div>
          <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
            <div className="text-2xl font-bold">{replyCount}</div>
            <div className="text-sm text-gray-500 dark:text-gray-400">Replies</div>
          </div>
          <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
            <div className="text-2xl font-bold">{likesReceived}</div>
            <div className="text-sm text-gray-500 dark:text-gray-400">Likes received</div>
          </div>
          <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
            <div className="text-2xl font-bold">{daysActive}</div>
            <div className="text-sm text-gray-500 dark:text-gray-400">Days active</div>
          </div>
        </div>
      </div>
      
      {/* Recent Threads */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Recent Threads</h2>
          {threadCount > 2 && (
            <button className="text-sm text-primary-500 hover:text-primary-600 dark:hover:text-primary-400">
              View All
            </button>
          )}
        </div>
        
        <div className="space-y-4">
          {threads && threads.length > 0 ? (
            threads.slice(0, 3).map(thread => (
              <div key={thread.id} className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4">
                <Link href={`/threads/${thread.id}`}>
                  <h3 className="font-semibold text-lg hover:text-primary-500 transition-colors cursor-pointer">
                    {thread.title}
                  </h3>
                </Link>
                <div className="flex items-center text-sm mt-2 mb-3">
                  <span className="text-xs text-gray-500 dark:text-gray-400">Posted in</span>
                  <span className="mx-1 text-xs text-gray-400 dark:text-gray-500">•</span>
                  <Link href={`/categories/${thread.categoryId}`}>
                    <span className="text-xs font-medium text-primary-500 hover:underline">
                      {thread.category.name}
                    </span>
                  </Link>
                  <span className="mx-1 text-xs text-gray-400 dark:text-gray-500">•</span>
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    {formatDistanceToNow(new Date(thread.createdAt), { addSuffix: true })}
                  </span>
                </div>
                <div className="flex items-center text-xs text-gray-500 dark:text-gray-400">
                  <span className="flex items-center mr-4">
                    <i className="ri-message-3-line mr-1"></i> {thread.replyCount} replies
                  </span>
                  <span className="flex items-center">
                    <i className="ri-thumb-up-line mr-1"></i> 15 likes
                  </span>
                </div>
              </div>
            ))
          ) : (
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 text-center border border-gray-200 dark:border-gray-700">
              <p className="text-gray-600 dark:text-gray-400">
                {isOwnProfile 
                  ? "You haven't created any threads yet." 
                  : "This user hasn't created any threads yet."}
              </p>
              {isOwnProfile && (
                <Link href="/">
                  <Button className="mt-4">
                    Browse Categories
                  </Button>
                </Link>
              )}
            </div>
          )}
        </div>
      </div>
      
      {/* Recent Replies */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Recent Replies</h2>
          {replyCount > 2 && (
            <button className="text-sm text-primary-500 hover:text-primary-600 dark:hover:text-primary-400">
              View All
            </button>
          )}
        </div>
        
        <div className="space-y-4">
          {replies && replies.length > 0 ? (
            replies.slice(0, 3).map(reply => (
              <div key={reply.id} className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4">
                <div className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                  Replied to{" "}
                  <Link href={`/threads/${reply.threadId}`}>
                    <span className="font-medium text-gray-700 dark:text-gray-300 hover:text-primary-500 dark:hover:text-primary-400">
                      Thread #{reply.threadId}
                    </span>
                  </Link>
                </div>
                <div className="text-sm mb-2 line-clamp-2">
                  {reply.content}
                </div>
                <div className="flex items-center text-xs text-gray-500 dark:text-gray-400">
                  <span className="flex items-center mr-4">
                    <i className="ri-thumb-up-line mr-1"></i> {reply.likes} likes
                  </span>
                  <span>
                    {formatDistanceToNow(new Date(reply.createdAt), { addSuffix: true })}
                  </span>
                </div>
              </div>
            ))
          ) : (
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 text-center border border-gray-200 dark:border-gray-700">
              <p className="text-gray-600 dark:text-gray-400">
                {isOwnProfile 
                  ? "You haven't replied to any threads yet." 
                  : "This user hasn't replied to any threads yet."}
              </p>
              {isOwnProfile && (
                <Link href="/">
                  <Button className="mt-4">
                    Browse Discussions
                  </Button>
                </Link>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
