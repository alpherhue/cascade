import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Category } from "@shared/schema";
import CategoryCard from "@/components/category-card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";

// WebSocket connection for real-time updates
const setupWebSocket = () => {
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  const wsUrl = `${protocol}//${window.location.host}/ws`;
  
  const socket = new WebSocket(wsUrl);
  
  socket.onmessage = (event) => {
    const data = JSON.parse(event.data);
    console.log("WebSocket message:", data);
    
    // Handle real-time updates here
    if (data.type === "category_created" || data.type === "thread_created") {
      // Invalidate queries to refresh data
    }
  };
  
  socket.onclose = () => {
    // Reconnect logic could go here
    console.log("WebSocket disconnected");
  };
  
  return socket;
};

export default function HomePage() {
  const [socket, setSocket] = useState<WebSocket | null>(null);
  
  // Setup WebSocket connection
  useEffect(() => {
    const ws = setupWebSocket();
    setSocket(ws);
    
    return () => {
      ws.close();
    };
  }, []);
  
  // Fetch categories
  const { data: categories, isLoading, error } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Featured categories (first 3)
  const featuredCategories = categories?.slice(0, 3) || [];
  
  // Regular categories (rest)
  const regularCategories = categories?.slice(3) || [];
  
  return (
    <div className="mb-12">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Categories</h1>
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" className="text-sm">
            <i className="ri-filter-3-line mr-1"></i> Filter
          </Button>
          <Button variant="outline" size="sm" className="text-sm">
            <i className="ri-sort-desc-line mr-1"></i> Sort
          </Button>
        </div>
      </div>
      
      {/* Loading state */}
      {isLoading && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 mb-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-white dark:bg-gray-800 rounded-lg p-5 border border-gray-200 dark:border-gray-700">
                <div className="flex justify-between items-start">
                  <div className="flex items-center">
                    <Skeleton className="h-8 w-8 rounded-md mr-3" />
                    <Skeleton className="h-6 w-32" />
                  </div>
                  <Skeleton className="h-5 w-16 rounded-full" />
                </div>
                <Skeleton className="h-4 w-full mt-4" />
                <Skeleton className="h-4 w-3/4 mt-2" />
                <div className="flex justify-between mt-4">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-4 w-24" />
                </div>
              </div>
            ))}
          </div>
          
          <h2 className="text-xl font-semibold mb-4">All Categories</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
              <div key={i} className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Skeleton className="h-5 w-5 rounded-md mr-2" />
                    <Skeleton className="h-5 w-28" />
                  </div>
                  <Skeleton className="h-4 w-8" />
                </div>
                <Skeleton className="h-4 w-full mt-3" />
                <Skeleton className="h-4 w-3/4 mt-1" />
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Error state */}
      {error && (
        <div className="bg-red-50 dark:bg-red-900/20 text-red-800 dark:text-red-200 p-4 rounded-md">
          <p>Error loading categories. Please try again later.</p>
        </div>
      )}
      
      {/* Content */}
      {categories && !isLoading && (
        <>
          {/* Featured categories */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 mb-8">
            {featuredCategories.map((category) => (
              <CategoryCard 
                key={category.id} 
                category={category} 
                threadCount={Math.floor(Math.random() * 5000) + 500}
                todayPosts={Math.floor(Math.random() * 300) + 50}
                featured={true}
              />
            ))}
          </div>
          
          {/* All categories */}
          <h2 className="text-xl font-semibold mb-4">All Categories</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {regularCategories.map((category) => (
              <CategoryCard 
                key={category.id} 
                category={category} 
                threadCount={Math.floor(Math.random() * 3000) + 200}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
